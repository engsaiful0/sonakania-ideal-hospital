<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Section_model extends CI_Model
{
    private $table = 'test_sections';

    public function get_by_panel($panel_id)
    {
        return $this->db->get_where($this->table, ['panel_id' => $panel_id])->result();
    }

    public function insert($data)
    {
        return $this->db->insert($this->table, $data);
    }

    public function update($id, $data)
    {
        return $this->db->where('id', $id)->update($this->table, $data);
    }

    public function delete($id)
    {
        return $this->db->where('id', $id)->delete($this->table);
    }
}