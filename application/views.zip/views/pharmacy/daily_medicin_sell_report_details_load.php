<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <style>
            body
            {
                width:100%;
                background: rgb(204,204,204); 
                overflow-x: hidden;


            }
            page[size="A4"] {
                background: white;
                width: 21cm;
                height: 29cm;
                display: block;
                margin: 0 auto;
                margin-bottom: 0.5cm;
                box-shadow: 0 0 0.1cm rgba(0,0,0,0.5);
                -o-box-shadow: 0 0 0.1cm rgba(0,0,0,0.5);
                -webkit-box-shadow: 0 0 0.1cm rgba(0,0,0,0.5);
                -moz-box-shadow: 0 0 0.1cm rgba(0,0,0,0.5);

            }

            @media print {
                body, page[size="A4"] {
                    margin: 0;
                    box-shadow: 0;

                }
            }

            .first
            {
                width:100%;
                height:29cm;
                margin:auto; padding:5px 0px 0px 0px;
            }
            .second
            {
                width:728px;
                height:600px;
                margin:auto; 
                margin-top: 40px
            }
            .third
            {
                width:607px;
                height:820px;
                margin:auto;
            }
            h2{font-size:24px;}
            #footer
            {
                width:400px;  
                margin:auto;
                background-color:#FFF;
            }
            #footer a
            {
                text-decoration:none;
                text-align:center;

            }

            @page {
                size: A4;
                margin: 0;
            }
            @media print {
                .first {

                    margin: 0;
                    border: initial;
                    border-radius: initial;
                    width: initial;
                    min-height: initial;
                    box-shadow: initial;
                    background: initial;
                    page-break-after: always;
                    -webkit-print-color-adjust: exact;

                }
            }
            @media print{
                #print{
                    display:none;
                }
                .print{
                    display:none;
                }
            }

            .upon{
                width:70%;
                height:auto;
                margin:auto;

            }
            #site_header_logo{
                position: relative;
                width:15%;
                height:100px;
                float:left;
                margin-top:10px;
                padding-left:80px;
            }
            a{
                text-decoration:none;
                color:inherit;
            }
            a.tooltip {outline:none;}
            a.tooltip strong {line-height:30px;}
            a.tooltip:hover {text-decoration:none;} 
            a.tooltip span {
                z-index:10;display:none; padding:14px 20px;
                margin-top:30px; margin-left:2px;
                width:300px; line-height:16px;
            }
            a.tooltip:hover span{
                display:inline; position:absolute; color:#111;
                border:1px solid #DCA; background:#fffAF0;

            }
            .callout {z-index:20;position:absolute;top:30px;border:0;left:-12px;}

            /*CSS3 extras*/
            a.tooltip span
            {
                border-radius:4px;
                box-shadow: 5px 5px 8px #CCC;
            }
            .boxright{width:35%; height:100px; float:left;  }
            .fbox1{width:320px; float:left; margin-left:39px; border-collapse: collapse; text-align:left; }
            .fbox1 td{height:25px;  line-height:16px}

            @media print {
                .offs{display:none;}
            }
            tr:hover{background-color:#91b8f7}
            @font-face {
                font-family: 'NikoshBAN';
                src: url('../assets/fonts/NikoshBAN.ttf') format('truetype');

            }

        </style>

        <title>Daily Medicin Sells Report</title>
    </head>
    <body>
        <div id="report" id="report" style="width: 95%;margin:0 auto;margin-left:45px;margin-top:40px;">
            <?php
            $total_retail_sell_payment = $this->db
                    ->where('date>=', date('Y-m-d', strtotime($from_date)))
                    ->where('is_deleted', '0')
                    ->where('date<=', date('Y-m-d', strtotime($to_date)))
                    ->get('sales');
            $total_profit_rows = $total_retail_sell_payment->num_rows();
            $page_limit = ceil($total_profit_rows / 45);
            //echo $page_limit;
            $from = -45;
            $start = 0;
            $grand_due = 0;
            $grand_paid = 0;
            $grand_sell = 0;
            $grand_sell_total = 0;
            $grand_sell_discount = 0;
            $grand_sell_nettotal = 0;
            for ($page_no = 1; $page_no <= $page_limit; $page_no++):
                ?>
                <page size="A4">
                    <div class="first">
                        <div class="second">
                            <table border="1" style="width: 100%;border-collapse:collapse;margin:0 auto;color:black">
                                <tr>
                                    <td colspan="9" style="text-align: center ">
                                        Sales From date <b><?php echo date('d-m-Y', strtotime($from_date)); ?></b> To date <b><?php echo date('d-m-Y', strtotime($to_date)); ?></b>
                                    </td>
                                </tr>

                                <tr>
                                    <td>Sl</td>
                                    <td>Customer</td>
                                    <td>Bill No</td>
                                    <td>Total</td>
                                    <td>Discount</td>
                                    <td>Net Total</td>
                                    <td>Paid</td>
                                    <td>Due</td>
                                    <td>Date</td>           
                                </tr>
                                <?php
                                $query = '';


                                $from = $from + 45;
                                $this->db->select('*');
                                $this->db->order_by('sales_id', 'asc');
                                $this->db->where('date>=', date('Y-m-d', strtotime($from_date)))
                                        ->where('is_deleted', '0')
                                        ->where('date<=', date('Y-m-d', strtotime($to_date)));
                                $this->db->from('sales');
                                $this->db->limit(45, $from);
                                $query_profit = $this->db->get();
                                $query = $query_profit->result();
                                $sl = 1;
                                foreach ($query as $query_value) {
                                    $customer = $this->db->where('customer_id', $query_value->customer_id)->get('customer')->row();
                                    ?>
                                    <tr>
                                        <td>
                                            <?php echo $sl++ ?>
                                        </td>
                                        <td>
                                            <?php echo $customer->name ?>
                                        </td>
                                        <td>
                                            <?php echo $query_value->bill_no ?>
                                        </td>
                                        <td>
                                            <?php
                                            echo $query_value->total;
                                            $grand_sell_total += $query_value->total;
                                            ?>
                                        </td>
                                        <td>
                                            <?php
                                            echo $query_value->discount;
                                            $grand_sell_discount += $query_value->discount;
                                            ?>
                                        </td>
                                        <td>
                                            <?php
                                            echo $query_value->nettotal;
                                            $grand_sell_nettotal += $query_value->nettotal;
                                            ?>
                                        </td>
                                        <td>
                                            <?php
                                            echo $query_value->paid;
                                            $grand_paid += $query_value->paid;
                                            ?>
                                        </td>
                                        <td>
                                            <?php
                                            echo $query_value->due;
                                            $grand_due += $query_value->due;
                                            ?>
                                        </td>
                                        <td>
                                            <?php echo date('d-m-Y', strtotime($query_value->date)) ?>
                                        </td>

                                    </tr>
                                    <?php
                                }
                                ?>
                                <tr>   
                                    <td></td>
                                    <td></td>
                                    <td style="font-weight: bold">Total</td>
                                    <td style="font-weight: bold"><?php echo number_format($grand_sell_total, 0) ?></td>
                                    <td style="font-weight: bold"><?php echo number_format($grand_sell_discount, 0) ?></td>
                                    <td style="font-weight: bold"><?php echo number_format($grand_sell_nettotal, 0) ?></td>
                                    <td style="font-weight: bold"><?php echo number_format($grand_paid, 0) ?></td>
                                    <td style="font-weight: bold"><?php echo number_format($grand_due, 0) ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </page>
                <div style="height: 100px; "></div>

                <?php
            endfor;
            ?>

        </div>
    </body>
</html>