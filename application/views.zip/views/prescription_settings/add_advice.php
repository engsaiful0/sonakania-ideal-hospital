<div class="container-fluid" style=" background-color: white;width: 100%;">
    <div class="panel panel-primary" style="width: 100%;margin: 0 auto">
        <div class="panel-heading">
            <h3 style="text-align: center">Add Advice</h3>
        </div>
        <div class="panel-body">
            <iframe src="<?php echo site_url('SettingsPrescriptionController/add_advice_frame'); ?>" name="frame" style="width: 100%; height: 650px; border: 0"></iframe>
        </div>
    </div>
</div>