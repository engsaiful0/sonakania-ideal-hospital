<link href="<?php echo base_url() ?>css/card_boostrap.css" rel="stylesheet">
<style type="text/css">
    .card {
        background-color: #fff;
        border-radius: 10px;
        border: none;
        position: relative;
        margin-bottom: 30px;
        box-shadow: 0 0.46875rem 2.1875rem rgba(90, 97, 105, 0.1), 0 0.9375rem 1.40625rem rgba(90, 97, 105, 0.1), 0 0.25rem 0.53125rem rgba(90, 97, 105, 0.12), 0 0.125rem 0.1875rem rgba(90, 97, 105, 0.1);
    }

    .l-bg-cherry {
        background: linear-gradient(to right, #493240, #f09) !important;
        color: #fff;
    }

    .l-bg-blue-dark {
        background: linear-gradient(to right, #373b44, #4286f4) !important;
        color: #fff;
    }

    .l-bg-green-dark {
        background: linear-gradient(to right, #0a504a, #38ef7d) !important;
        color: #fff;
    }

    .l-bg-orange-dark {
        background: linear-gradient(to right, #a86008, #ffba56) !important;
        color: #fff;
    }



    .card .card-statistic-3 .card-icon {
        text-align: center;
        line-height: 50px;
        margin-left: 15px;
        color: #000;
        position: absolute;
        right: -5px;
        top: 20px;
        opacity: 0.1;
    }

    .l-bg-cyan {
        background: linear-gradient(135deg, #289cf5, #84c0ec) !important;
        color: #fff;
    }

    .l-bg-green {
        background: linear-gradient(135deg, #23bdb8 0%, #43e794 100%) !important;
        color: #fff;
    }

    .l-bg-orange {
        background: linear-gradient(to right, #f9900e, #ffba56) !important;
        color: #fff;
    }

    .l-bg-cyan {
        background: linear-gradient(135deg, #289cf5, #84c0ec) !important;
        color: #fff;
    }
</style>

<div class="container-fluid" style="background-color: white; width: 100%;">
    <?php $permissions = $this->session->userdata('permissions'); ?>
    <?php if (in_array('account_dashboard', $permissions)) { ?>
        <div class="panel panel-primary" style="width: 100%; margin: 0 auto;">
            <div class="panel-heading">
                <h3 style="text-align: center;">Account Dashboard</h3>
            </div>
            <div class="panel-body">
                <fieldset>
                    <legend>
                        Today
                    </legend>
                    <?php
                    error_reporting(0);
                    // Get today's date in the 'Y-m-d' format
                    $today = date('Y-m-d');

                    // Fetch the sum of the amount from the debit_voucher table for the current account for today
                    $total_debit_amount_today = $this->db->select_sum('total_amount')
                        ->where('date', $today) // Filter for today's date
                        ->get('debit_voucher')
                        ->row()
                        ->total_amount;

                    $total_credit_amount_today = $this->db->select_sum('total_amount')
                        ->where('date', $today) // Filter for today's date
                        ->get('credit_voucher')
                        ->row()
                        ->total_amount;

                    $total_purchase_amount_today = $this->db->select_sum('total')
                        ->where('date', $today) // Filter for today's date
                        ->get('purchase_goods')
                        ->row()
                        ->total;

                    ?>
                    <div class="col-xl-4 col-lg-4">
                        <div class="card l-bg-cherry">
                            <div class="card-statistic-3 p-4">
                                <div class="card-icon card-icon-large"><i class="fas fa-shopping-cart"></i></div>
                                <div class="mb-4">
                                    <h5 class="card-title mb-0">Debit Amount</h5>
                                </div>
                                <div class="row align-items-center mb-2 d-flex">
                                    <div class="col-8">
                                        <h2 class="d-flex align-items-center mb-0">
                                            <?php
                                            echo number_format($total_debit_amount_today);
                                            ?>
                                        </h2>
                                    </div>

                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4">
                        <div class="card l-bg-blue-dark">
                            <div class="card-statistic-3 p-4">
                                <div class="card-icon card-icon-large"><i class="fas fa-users"></i></div>
                                <div class="mb-4">
                                    <h5 class="card-title mb-0">Credit Amount</h5>
                                </div>
                                <div class="row align-items-center mb-2 d-flex">
                                    <div class="col-8">
                                        <h2 class="d-flex align-items-center mb-0">
                                            <?php
                                            echo number_format($total_credit_amount_today);
                                            ?>
                                        </h2>
                                    </div>

                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4">
                        <div class="card l-bg-green-dark">
                            <div class="card-statistic-3 p-4">
                                <div class="card-icon card-icon-large"><i class="fas fa-ticket-alt"></i></div>
                                <div class="mb-4">
                                    <h5 class="card-title mb-0">Purchase Amount</h5>
                                </div>
                                <div class="row align-items-center mb-2 d-flex">
                                    <div class="col-8">
                                        <h2 class="d-flex align-items-center mb-0">
                                            <?php
                                            echo number_format($total_purchase_amount_today);
                                            ?>
                                        </h2>
                                    </div>

                                </div>

                            </div>
                        </div>
                    </div>
                    <!-- <div class="col-xl-3 col-lg-3">
                    <div class="card l-bg-orange-dark">
                        <div class="card-statistic-3 p-4">
                            <div class="card-icon card-icon-large"><i class="fas fa-dollar-sign"></i></div>
                            <div class="mb-4">
                                <h5 class="card-title mb-0">Stock Quantity</h5>
                            </div>
                            <div class="row align-items-center mb-2 d-flex">
                                <div class="col-8">
                                    <h2 class="d-flex align-items-center mb-0">
                                        $11.61k
                                    </h2>
                                </div>
                                <div class="col-4 text-right">
                                    <span>2.5% <i class="fa fa-arrow-up"></i></span>
                                </div>
                            </div>
                            <div class="progress mt-1 " data-height="8" style="height: 8px;">
                                <div class="progress-bar l-bg-cyan" role="progressbar" data-width="25%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100" style="width: 25%;"></div>
                            </div>
                        </div>
                    </div>
                </div> -->

                </fieldset>
                <fieldset>
                    <legend>
                        This Month
                    </legend>
                    <?php
                    error_reporting(0);
                    // Get the first and last days of the current month in 'Y-m-d' format
                    $first_day_of_month = date('Y-m-01'); // First day of the current month
                    $last_day_of_month = date('Y-m-t');   // Last day of the current month

                    // Fetch the sum of the amount from the debit_voucher table for the current account for the current month
                    $total_debit_amount_month = $this->db->select_sum('total_amount')
                        ->where('date >=', $first_day_of_month)
                        ->where('date <=', $last_day_of_month)
                        ->get('debit_voucher')
                        ->row()
                        ->total_amount;

                    // Fetch the sum of the amount from the credit_voucher table for the current account for the current month
                    $total_credit_amount_month = $this->db->select_sum('total_amount')
                        ->where('date >=', $first_day_of_month)
                        ->where('date <=', $last_day_of_month)
                        ->get('credit_voucher')
                        ->row()
                        ->total_amount;

                    // Fetch the sum of the total from the purchase_goods table for the current account for the current month
                    $total_purchase_amount_month = $this->db->select_sum('total')
                        ->where('date >=', $first_day_of_month)
                        ->where('date <=', $last_day_of_month)
                        ->get('purchase_goods')
                        ->row()
                        ->total;

                    ?>
                    <div class="col-xl-4 col-lg-4">
                        <div class="card l-bg-cherry">
                            <div class="card-statistic-3 p-4">
                                <div class="card-icon card-icon-large"><i class="fas fa-shopping-cart"></i></div>
                                <div class="mb-4">
                                    <h5 class="card-title mb-0">Debit Amount</h5>
                                </div>
                                <div class="row align-items-center mb-2 d-flex">
                                    <div class="col-8">
                                        <h2 class="d-flex align-items-center mb-0">
                                            <?php
                                            echo number_format($total_debit_amount_month);
                                            ?>
                                        </h2>
                                    </div>

                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4">
                        <div class="card l-bg-blue-dark">
                            <div class="card-statistic-3 p-4">
                                <div class="card-icon card-icon-large"><i class="fas fa-users"></i></div>
                                <div class="mb-4">
                                    <h5 class="card-title mb-0">Credit Amount</h5>
                                </div>
                                <div class="row align-items-center mb-2 d-flex">
                                    <div class="col-8">
                                        <h2 class="d-flex align-items-center mb-0">
                                            <?php
                                            echo number_format($total_credit_amount_month);
                                            ?>
                                        </h2>
                                    </div>

                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4">
                        <div class="card l-bg-green-dark">
                            <div class="card-statistic-3 p-4">
                                <div class="card-icon card-icon-large"><i class="fas fa-ticket-alt"></i></div>
                                <div class="mb-4">
                                    <h5 class="card-title mb-0">Purchase Amount</h5>
                                </div>
                                <div class="row align-items-center mb-2 d-flex">
                                    <div class="col-8">
                                        <h2 class="d-flex align-items-center mb-0">
                                            <?php
                                            echo number_format($total_purchase_amount_month);
                                            ?>
                                        </h2>
                                    </div>

                                </div>

                            </div>
                        </div>
                    </div>
                    <!-- <div class="col-xl-3 col-lg-3">
                    <div class="card l-bg-orange-dark">
                        <div class="card-statistic-3 p-4">
                            <div class="card-icon card-icon-large"><i class="fas fa-dollar-sign"></i></div>
                            <div class="mb-4">
                                <h5 class="card-title mb-0">Stock Quantity</h5>
                            </div>
                            <div class="row align-items-center mb-2 d-flex">
                                <div class="col-8">
                                    <h2 class="d-flex align-items-center mb-0">
                                        $11.61k
                                    </h2>
                                </div>
                                <div class="col-4 text-right">
                                    <span>2.5% <i class="fa fa-arrow-up"></i></span>
                                </div>
                            </div>
                            <div class="progress mt-1 " data-height="8" style="height: 8px;">
                                <div class="progress-bar l-bg-cyan" role="progressbar" data-width="25%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100" style="width: 25%;"></div>
                            </div>
                        </div>
                    </div>
                </div> -->

                </fieldset>
                <div class="container">
                    <h2 class="text-center mt-4">Bar Chart of All Costs(Debit) for This Month</h2>
                    <div class="bar-container d-flex align-items-end justify-content-around">
                        <?php
                        // Fetch all debit accounts ordered by account_name
                        $debit_accounts = $this->db->select('*')->order_by('account_name')->get('debit_account')->result();

                        foreach ($debit_accounts as $debit_account) {
                            // Get the first and last day of the current month
                            $first_day_of_month = date('Y-m-01');
                            $last_day_of_month = date('Y-m-t');

                            // Fetch the sum of amount from the debit_voucher table for the current account within the current month
                            $total_amount = $this->db->select_sum('total_amount')
                                ->where('debit_account_id', $debit_account->debit_account_id)
                                ->where('date >=', $first_day_of_month)
                                ->where('date <=', $last_day_of_month)
                                ->get('debit_voucher')
                                ->row()
                                ->total_amount;

                            if ($total_amount == 0) {
                                continue;
                            }

                            $max_amount = 100000; // Adjust this to match your data range
                            $bar_height = ($total_amount / $max_amount) * 100;
                            $bar_height = min($bar_height, 100);
                        ?>
                            <div data-toggle="tooltip" title="<?= $debit_account->account_name . ': ' . $total_amount ?>" id="bar_<?php echo $debit_account->debit_account_id ?>" class="bar" style="height: <?= $bar_height ?>%;">
                                <span class="bar-label"><?= $total_amount ?></span>
                            </div>

                        <?php
                        }
                        ?>
                    </div>
                </div>
                <script>
                    $(document).ready(function() {
                        $('[data-toggle="tooltip"]').tooltip();
                    });
                </script>

                <!-- Additional CSS for bar styling -->
                <style>
                    .bar-container {
                        height: 300px;
                        border-left: 2px solid #ccc;
                        border-bottom: 2px solid #ccc;
                        margin-top: 20px;
                        display: flex;
                        align-items: flex-end;
                        /* Align bars to the bottom */
                    }

                    .bar {
                        width: 40px;
                        background-color: #007bff;
                        text-align: center;
                        color: white;
                        border-radius: 5px 5px 0 0;
                        position: relative;
                        transition: all 0.3s;
                    }

                    .bar-wrapper {
                        display: flex;
                        flex-direction: column;
                        align-items: center;
                        margin: 0 10px;
                    }



                    .bar:hover {
                        background-color: #0056b3;
                    }

                    .bar-label {
                        position: absolute;
                        top: -25px;
                        left: 50%;
                        transform: translateX(-50%);
                        font-weight: bold;
                        color: #333;
                    }

                    .x-axis-label {
                        font-weight: bold;
                        font-size: 12px;
                        margin-top: 5px;
                    }
                </style>





            </div>
        </div>
    <?php } ?>
</div>